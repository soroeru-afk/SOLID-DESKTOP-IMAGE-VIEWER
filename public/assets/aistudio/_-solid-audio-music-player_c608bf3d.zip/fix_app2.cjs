const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

// Fix the corrupted parts
code = code.replace(
    /<button onClick=\{\(\) => set          \) : \(\n            <div className=\"flex items-center gap-3\">/g,
    `<button onClick={() => setEditingTrackId(null)} className="px-1" title="Cancel" style={{ color: 'var(--theme-textDim)' }}><X size={12} /></button>
            </div>
          ) : (
            <div className="flex items-center gap-3">`
);

code = code.replace(
    /              \}\)derColor: 'var(--theme-borderActive)', color: iconColor \}\}>\n                  <Palette size=\{10\} \/>\n                <\/button>\n            \)\}/g,
    `              )}`
);

fs.writeFileSync('src/App.tsx', code);

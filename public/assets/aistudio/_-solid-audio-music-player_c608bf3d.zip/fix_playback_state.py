import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

# 1. In loadState, add the fetches
code = code.replace(
    "const savedActivePlaylistId = await get('v2_solidActivePlaylistId');",
    "const savedActivePlaylistId = await get('v2_solidActivePlaylistId');\n        const savedPlayingPlaylistId = await get('v2_solidPlayingPlaylistId');\n        const savedPlaybackQueueIds = await get('v2_solidPlaybackQueueIds');\n        const savedCurrentTrackIndex = await get('v2_solidCurrentTrackIndex');"
)

# 2. Add restoration logic inside if (savedLibrary && savedPlaylists)
restoration_logic = """
          // Restore playlists
          const validPlaylists = savedPlaylists.map((p: any) => ({
            ...p,
            tracks: p.tracks.map((pt: Track) => libraryMap.get(pt.id)).filter(Boolean) as Track[]
          }));
          setPlaylists(validPlaylists);

          if (savedPlayingPlaylistId) setPlayingPlaylistId(savedPlayingPlaylistId);
          if (savedPlaybackQueueIds && Array.isArray(savedPlaybackQueueIds)) {
            const restoredQueue = savedPlaybackQueueIds.map(id => libraryMap.get(id)).filter(Boolean) as Track[];
            setPlaybackQueue(restoredQueue);
            if (savedCurrentTrackIndex !== undefined && savedCurrentTrackIndex >= 0 && savedCurrentTrackIndex < restoredQueue.length) {
              setCurrentTrackIndex(savedCurrentTrackIndex);
            }
          }
"""
code = code.replace(
"""          // Restore playlists
          const validPlaylists = savedPlaylists.map((p: any) => ({
            ...p,
            tracks: p.tracks.map((pt: Track) => libraryMap.get(pt.id)).filter(Boolean) as Track[]
          }));
          setPlaylists(validPlaylists);""",
restoration_logic
)

# 3. Save logic
save_logic = """        set('v2_solidListFontSize', listFontSize).catch(console.error);
        set('v2_solidActivePlaylistId', activePlaylistId).catch(console.error);
        set('v2_solidPlayingPlaylistId', playingPlaylistId).catch(console.error);
        set('v2_solidPlaybackQueueIds', playbackQueue.map(t => t.id)).catch(console.error);
        set('v2_solidCurrentTrackIndex', currentTrackIndex).catch(console.error);
"""
code = code.replace(
"""        set('v2_solidListFontSize', listFontSize).catch(console.error);
        set('v2_solidActivePlaylistId', activePlaylistId).catch(console.error);""",
save_logic
)

# 4. Update the useEffect dependency array
code = code.replace(
    "}, [library, playlists, sidebarWidth, colWidths, colVisibility, colOrder, themeIndex, listFontSize, activePlaylistId, isInitialized]);",
    "}, [library, playlists, sidebarWidth, colWidths, colVisibility, colOrder, themeIndex, listFontSize, activePlaylistId, playingPlaylistId, playbackQueue, currentTrackIndex, isInitialized]);"
)

with open('src/App.tsx', 'w') as f:
    f.write(code)

print("Done")

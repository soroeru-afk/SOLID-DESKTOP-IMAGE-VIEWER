import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

code = code.replace(
    'className="w-24 flex-shrink-0 flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity pr-2"',
    'className="w-24 flex-shrink-0 flex items-center justify-end gap-1 transition-opacity pr-2"'
)

with open('src/App.tsx', 'w') as f:
    f.write(code)

print("Done")

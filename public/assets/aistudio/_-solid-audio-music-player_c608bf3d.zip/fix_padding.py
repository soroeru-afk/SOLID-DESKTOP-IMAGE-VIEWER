import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

# 1. Add pl-3 to column containers
code = code.replace(
    '<div className="flex items-center gap-3">\n              {colOrder.map(col => {',
    '<div className="flex items-center gap-3 pl-3">\n              {colOrder.map(col => {'
)

code = code.replace(
    '<div className="flex items-center gap-3">\n                    {colOrder.map(col => {',
    '<div className="flex items-center gap-3 pl-3">\n                    {colOrder.map(col => {'
)

# 2. Fix INDEX MAP text size
code = code.replace(
    '<span className="uppercase tracking-wider" style={{ color: \'var(--theme-textMuted)\', fontSize: \'var(--list-font-size-sm)\' }}>INDEX MAP</span>',
    '<span className="uppercase tracking-wider text-[11px]" style={{ color: \'var(--theme-textMuted)\' }}>INDEX MAP</span>'
)

# 3. Fix Playlist name text size
code = code.replace(
    "fontSize: 'var(--list-font-size-sm)'\n                }}",
    "fontSize: '12px'\n                }}"
)

with open('src/App.tsx', 'w') as f:
    f.write(code)

print("Done")

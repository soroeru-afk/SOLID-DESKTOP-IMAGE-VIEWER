import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

# Update load state
code = code.replace(
    "const savedThemeIndex = await get('v2_solidThemeIndex');",
    "const savedThemeIndex = await get('v2_solidThemeIndex');\n        const savedActivePlaylistId = await get('v2_solidActivePlaylistId');"
)

code = code.replace(
    "if (savedListFontSize !== undefined) setListFontSize(savedListFontSize);",
    "if (savedListFontSize !== undefined) setListFontSize(savedListFontSize);\n        if (savedActivePlaylistId) setActivePlaylistId(savedActivePlaylistId);"
)

# Update save state
code = code.replace(
    "set('v2_solidListFontSize', listFontSize).catch(console.error);",
    "set('v2_solidListFontSize', listFontSize).catch(console.error);\n        set('v2_solidActivePlaylistId', activePlaylistId).catch(console.error);"
)

code = code.replace(
    "}, [library, playlists, sidebarWidth, colWidths, colVisibility, colOrder, themeIndex, listFontSize, isInitialized]);",
    "}, [library, playlists, sidebarWidth, colWidths, colVisibility, colOrder, themeIndex, listFontSize, activePlaylistId, isInitialized]);"
)

with open('src/App.tsx', 'w') as f:
    f.write(code)

print("Done")

import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

target = '''    const onMove = (ev: MouseEvent) => {
      if (!colResizing.current) return;
      const delta = ev.clientX - colResizing.current.startX;
      const newWidth = Math.max(50, colResizing.current.startWidth + delta);
      setColWidths(prev => ({ ...prev, [colResizing.current!.key]: newWidth }));
    };'''

replacement = '''    const onMove = (ev: MouseEvent) => {
      if (!colResizing.current) return;
      const resizeKey = colResizing.current.key;
      const delta = ev.clientX - colResizing.current.startX;
      const newWidth = Math.max(50, colResizing.current.startWidth + delta);
      setColWidths(prev => ({ ...prev, [resizeKey]: newWidth }));
    };'''

code = code.replace(target, replacement)

with open('src/App.tsx', 'w') as f:
    f.write(code)

print("Done")

import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

# Fix row trackNumber to be padded
target1 = '''                    <div key="trackNumber" className="flex-shrink-0 text-center font-mono opacity-80" style={{ width: colWidths.trackNumber, fontSize: 'var(--list-font-size-sm)' }}>
                      {track.trackNumber || '-'}
                    </div>'''
replacement1 = '''                    <div key="trackNumber" className="flex-shrink-0 text-center font-mono opacity-80" style={{ width: colWidths.trackNumber, fontSize: 'var(--list-font-size-sm)' }}>
                      {track.trackNumber ? track.trackNumber.toString().padStart(2, '0') : '-'}
                    </div>'''
code = code.replace(target1, replacement1)

with open('src/App.tsx', 'w') as f:
    f.write(code)
print("Done 1")

import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

# Update `#` header column
header_target = '''                  <div className="relative w-10 flex-shrink-0 flex items-center justify-center">'''
header_replacement = '''                  <div className="relative w-16 flex-shrink-0 flex items-center justify-center">'''
code = code.replace(header_target, header_replacement)

with open('src/App.tsx', 'w') as f:
    f.write(code)

print("Done")

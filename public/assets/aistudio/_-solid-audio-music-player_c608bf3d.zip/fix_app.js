const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

const regex = /<div className="w-8 flex-shrink-0 flex items-center justify-center" onClick=\{\(e\) => toggleTrackSelection\(e, track\.id\)\}>[\s\S]*?\{editingTrackId === track\.id \? \(/;

const newCode = `<div className="w-8 flex-shrink-0 flex items-center justify-center" onClick={(e) => toggleTrackSelection(e, track.id)}>
              <div 
                  className="w-3 h-3 flex items-center justify-center border transition-colors"
                  style={{ 
                      backgroundColor: isSelected ? 'var(--theme-accent)' : 'transparent',
                      borderColor: isSelected ? 'var(--theme-accent)' : 'var(--theme-border)'
                  }}
              >
                  {isSelected && <Check size={8} className="text-white" />}
              </div>
          </div>
          <div className="w-8 flex-shrink-0 flex items-center justify-center relative" style={{ color: 'var(--theme-textDim)' }}>
            {isActive ? (
               <div className="absolute w-[6px] h-[6px] rounded-full" style={{ backgroundColor: 'var(--theme-accent)', boxShadow: \`0 0 8px var(--theme-accent)\` }}></div>
            ) : (
              <span style={{ fontSize: 'var(--list-font-size-xs)' }}>{(idx + 1).toString().padStart(2, '0')}</span>
            )}
          </div>
          {/* List Album Art Small */}
          {colVisibility.art && (
            <div 
              className="w-8 h-8 flex-shrink-0 mr-3 border flex items-center justify-center overflow-hidden relative"
              style={{ 
                borderColor: track.missing ? 'var(--theme-accent)' : 'var(--theme-border)', 
                backgroundColor: 'var(--theme-bg)',
                opacity: track.missing ? 0.5 : 1
              }}
            >
               {track.coverUrl ? (
                  <img src={track.coverUrl} className="w-full h-full object-cover" alt="" />
               ) : (
                  <Activity size={10} style={{ color: 'var(--theme-textDim)' }} />
               )}
            </div>
          )}
          
          {/* Track Info with Inline Edit */}
          {editingTrackId === track.id ? (`

code = code.replace(regex, newCode);
fs.writeFileSync('src/App.tsx', code);

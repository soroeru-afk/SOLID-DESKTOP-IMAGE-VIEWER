import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

target = '''        if (savedColOrder) {
          if (!savedColOrder.includes('art')) savedColOrder = ['art', ...savedColOrder];
          setColOrder(savedColOrder);
        }'''
replacement = '''        if (savedColOrder) {
          let updatedColOrder = savedColOrder;
          if (!updatedColOrder.includes('art')) updatedColOrder = ['art', ...updatedColOrder];
          setColOrder(updatedColOrder);
        }'''
code = code.replace(target, replacement)

target2 = '''                    opacity: draggedPlaylistId === pl.id ? 0.5 : 1,
                    fontSize: 'var(--list-font-size-sm)',
                    fontSize: 'var(--list-font-size-sm)'
                  }}'''
replacement2 = '''                    opacity: draggedPlaylistId === pl.id ? 0.5 : 1,
                    fontSize: 'var(--list-font-size-sm)'
                  }}'''
code = code.replace(target2, replacement2)

with open('src/App.tsx', 'w') as f:
    f.write(code)

print("Done")

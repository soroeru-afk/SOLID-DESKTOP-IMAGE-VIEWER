import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

code = code.replace(
    "fontSize: '12px'\n                }}",
    "fontSize: 'var(--list-font-size)'\n                }}"
)

with open('src/App.tsx', 'w') as f:
    f.write(code)

print("Done")

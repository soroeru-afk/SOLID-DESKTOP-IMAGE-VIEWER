import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

# 1. Update setColWidths initialization
target1 = '''  const [colWidths, setColWidths] = useState({
    fileName: 180,
    title: 300,
    artist: 180,
    album: 180
  });'''
replacement1 = '''  const [colWidths, setColWidths] = useState({
    index: 96,
    art: 40,
    trackNumber: 48,
    fileName: 180,
    title: 300,
    artist: 180,
    album: 180
  });'''
code = code.replace(target1, replacement1)

# 2. Update Header #
target2 = '''                  <div className="relative w-16 flex-shrink-0 flex items-center justify-center">
                    #
                    <div className="absolute right-0 top-0 bottom-0 w-[1px] bg-[var(--theme-border)] opacity-40 pointer-events-none" />
                  </div>'''
replacement2 = '''                  <div className="relative flex-shrink-0 flex items-center justify-center" style={{ width: colWidths.index }}>
                    #
                    <div onMouseDown={(e) => handleColMouseDown(e, 'index')} className="absolute right-0 top-0 bottom-0 w-[14px] cursor-col-resize flex justify-center z-20 group" style={{ transform: 'translateX(50%)' }}>
                      <div className="w-[1px] h-full bg-[var(--theme-border)] opacity-40 group-hover:bg-[var(--theme-accent)] group-hover:opacity-100 transition-colors" />
                    </div>
                  </div>'''
code = code.replace(target2, replacement2)

# 3. Update Header ART
target3 = '''                          <div key="art" draggable onDragStart={(e) => handleColDragStart(e, 'art')} onDragOver={handleColDragOver} onDrop={(e) => handleColDrop(e, 'art')} className="relative w-8 flex-shrink-0 flex items-center justify-center cursor-grab mr-3">
                            ART
                            <div className="absolute right-[-6px] top-0 bottom-0 w-[1px] bg-[var(--theme-border)] opacity-40 pointer-events-none" />
                          </div>'''
replacement3 = '''                          <div key="art" draggable onDragStart={(e) => handleColDragStart(e, 'art')} onDragOver={handleColDragOver} onDrop={(e) => handleColDrop(e, 'art')} className="relative flex-shrink-0 flex items-center justify-center cursor-grab" style={{ width: colWidths.art, marginRight: '12px' }}>
                            ART
                            <div onMouseDown={(e) => handleColMouseDown(e, 'art')} className="absolute right-[-12px] top-0 bottom-0 w-[14px] cursor-col-resize flex justify-center z-20 group" style={{ transform: 'translateX(50%)' }}>
                              <div className="w-[1px] h-full bg-[var(--theme-border)] opacity-40 group-hover:bg-[var(--theme-accent)] group-hover:opacity-100 transition-colors" />
                            </div>
                          </div>'''
code = code.replace(target3, replacement3)

# 4. Update Header trackNumber
target4 = '''                          <div key="trackNumber" draggable onDragStart={(e) => handleColDragStart(e, 'trackNumber')} onDragOver={handleColDragOver} onDrop={(e) => handleColDrop(e, 'trackNumber')} className="relative w-10 flex-shrink-0 flex items-center justify-center pr-2">
                            <div onClick={() => handleSort('trackNumber')} className="flex-1 min-w-0 flex items-center justify-center gap-1 cursor-pointer hover:text-[var(--theme-textMain)]">
                              #No
                              {activeSortConfig.key === 'trackNumber' && (activeSortConfig.direction === 'asc' ? <ChevronUp size={10} className="shrink-0" /> : <ChevronDown size={10} className="shrink-0" />)}
                            </div>
                            <div className="absolute right-0 top-0 bottom-0 w-[1px] bg-[var(--theme-border)] opacity-40 pointer-events-none" />
                          </div>'''
replacement4 = '''                          <div key="trackNumber" draggable onDragStart={(e) => handleColDragStart(e, 'trackNumber')} onDragOver={handleColDragOver} onDrop={(e) => handleColDrop(e, 'trackNumber')} className="relative flex-shrink-0 flex items-center justify-center pr-2" style={{ width: colWidths.trackNumber }}>
                            <div onClick={() => handleSort('trackNumber')} className="flex-1 min-w-0 flex items-center justify-center gap-1 cursor-pointer hover:text-[var(--theme-textMain)]">
                              #No
                              {activeSortConfig.key === 'trackNumber' && (activeSortConfig.direction === 'asc' ? <ChevronUp size={10} className="shrink-0" /> : <ChevronDown size={10} className="shrink-0" />)}
                            </div>
                            <div onMouseDown={(e) => handleColMouseDown(e, 'trackNumber')} className="absolute right-0 top-0 bottom-0 w-[14px] cursor-col-resize flex justify-center z-20 group" style={{ transform: 'translateX(50%)' }}>
                              <div className="w-[1px] h-full bg-[var(--theme-border)] opacity-40 group-hover:bg-[var(--theme-accent)] group-hover:opacity-100 transition-colors" />
                            </div>
                          </div>'''
code = code.replace(target4, replacement4)

# 5. Update index cell in row
target5 = '''          <div className="flex items-center px-2 py-1 h-12 relative">
            <div className="w-16 flex-shrink-0 flex items-center justify-center" onClick={(e) => toggleTrackSelection(e, track.id)}>
              <div className="w-4 h-4 border rounded flex items-center justify-center" style={{ borderColor: 'var(--theme-border)' }}>
                {isSelected && <div className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: 'var(--theme-accent)' }} />}
              </div>
            </div>
            <div className="w-8 flex-shrink-0 flex items-center justify-center" onClick={(e) => toggleTrackSelection(e, track.id)}>
               {isActive && isPlaying ? (
                 <Activity size={12} style={{ color: 'var(--theme-accent)' }} />
               ) : (
                 <span className="font-mono opacity-40 text-xs">{(idx + 1).toString().padStart(2, '0')}</span>
               )}
            </div>
            <div className="flex items-center gap-3">'''
replacement5 = '''          <div className="flex items-center px-2 py-1 h-12 relative">
            <div className="flex-shrink-0 flex items-center justify-center" style={{ width: colWidths.index }}>
              <div className="w-16 flex-shrink-0 flex items-center justify-center h-full cursor-pointer" onClick={(e) => toggleTrackSelection(e, track.id)}>
                <div className="w-4 h-4 border rounded flex items-center justify-center" style={{ borderColor: 'var(--theme-border)' }}>
                  {isSelected && <div className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: 'var(--theme-accent)' }} />}
                </div>
              </div>
              <div className="flex-1 flex-shrink-0 flex items-center justify-center h-full cursor-pointer" onClick={(e) => toggleTrackSelection(e, track.id)}>
                 {isActive && isPlaying ? (
                   <Activity size={12} style={{ color: 'var(--theme-accent)' }} />
                 ) : (
                   <span className="font-mono opacity-40 text-xs">{(idx + 1).toString().padStart(2, '0')}</span>
                 )}
              </div>
            </div>
            <div className="flex items-center gap-3">'''
code = code.replace(target5, replacement5)

# 6. Update art cell in row
target6 = '''                    <div key="art" className="w-8 h-8 flex-shrink-0 border flex items-center justify-center overflow-hidden relative" style={{ borderColor: track.missing ? 'var(--theme-accent)' : 'var(--theme-border)', backgroundColor: 'var(--theme-bg)', opacity: track.missing ? 0.5 : 1 }}>'''
replacement6 = '''                    <div key="art" className="h-8 flex-shrink-0 border flex items-center justify-center overflow-hidden relative" style={{ width: colWidths.art, borderColor: track.missing ? 'var(--theme-accent)' : 'var(--theme-border)', backgroundColor: 'var(--theme-bg)', opacity: track.missing ? 0.5 : 1 }}>'''
code = code.replace(target6, replacement6)

# 7. Update trackNumber cell in row
target7 = '''                    <div key="trackNumber" className="w-10 flex-shrink-0 text-center font-mono opacity-80" style={{ fontSize: 'var(--list-font-size-sm)' }}>'''
replacement7 = '''                    <div key="trackNumber" className="flex-shrink-0 text-center font-mono opacity-80" style={{ width: colWidths.trackNumber, fontSize: 'var(--list-font-size-sm)' }}>'''
code = code.replace(target7, replacement7)

with open('src/App.tsx', 'w') as f:
    f.write(code)

print("Done")

import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

# Fix percentage widths for progress bars
code = code.replace(
    "${duration ? (currentTime / duration) * 100 : 0}%",
    "${duration && !isNaN(duration) && !isNaN(currentTime) ? (currentTime / duration) * 100 : 0}%"
)

# Fix sidebar width
code = code.replace(
    "const newWidth = Math.max(120, Math.min(800, startWidth + delta));",
    "const newWidth = Math.max(120, Math.min(800, (startWidth || 220) + delta));"
)

# Fix col widths
code = code.replace(
    "setColWidths(prev => ({ ...prev, [key]: Math.max(30, startWidth + delta) }));",
    "setColWidths(prev => ({ ...prev, [key]: Math.max(30, (startWidth || 100) + delta) }));"
)

code = code.replace(
    "if (savedSidebarWidth) setSidebarWidth(savedSidebarWidth);",
    "if (savedSidebarWidth && !isNaN(savedSidebarWidth)) setSidebarWidth(savedSidebarWidth);"
)

with open('src/App.tsx', 'w') as f:
    f.write(code)

print("Done")

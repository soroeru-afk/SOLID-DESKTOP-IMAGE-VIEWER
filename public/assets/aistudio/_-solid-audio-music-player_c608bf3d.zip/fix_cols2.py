import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

# Update `#` header column
header_target = '''                  <div className="w-10 flex-shrink-0 text-center">#</div>'''
header_replacement = '''                  <div className="relative w-10 flex-shrink-0 flex items-center justify-center">
                    #
                    <div className="absolute right-0 top-0 bottom-0 w-[14px] flex justify-center z-20 group" style={{ transform: 'translateX(50%)' }}>
                      <div className="w-[1px] h-full bg-[var(--theme-border)] opacity-40 transition-colors" />
                    </div>
                  </div>'''
code = code.replace(header_target, header_replacement)

with open('src/App.tsx', 'w') as f:
    f.write(code)

print("Done")

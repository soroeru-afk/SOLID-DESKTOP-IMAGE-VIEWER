import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

# 1. Remove tracking-wider from list header
code = code.replace('uppercase tracking-wider px-2', 'uppercase tracking-normal px-2')

# 2. Fix ART header alignment
target_art = '''                          <div key="art" draggable onDragStart={(e) => handleColDragStart(e, 'art')} onDragOver={handleColDragOver} onDrop={(e) => handleColDrop(e, 'art')} className="relative flex-shrink-0 flex items-center justify-center cursor-grab" style={{ width: colWidths.art }}>
                            ART'''
replacement_art = '''                          <div key="art" draggable onDragStart={(e) => handleColDragStart(e, 'art')} onDragOver={handleColDragOver} onDrop={(e) => handleColDrop(e, 'art')} className="relative flex-shrink-0 flex items-center pl-1 cursor-grab" style={{ width: colWidths.art }}>
                            ART'''
code = code.replace(target_art, replacement_art)

with open('src/App.tsx', 'w') as f:
    f.write(code)
print("Done align")

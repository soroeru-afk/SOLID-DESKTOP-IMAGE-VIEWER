const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

code = code.replace(
    /              <ChevronsDown size=\{10\} \/>\n            <\/button>\n          <\/div>\n        <\/div>\n      \);\n    \}\);\n  \}, \[displayTracks/g,
    `              <ChevronsDown size={10} />\n            </button>\n          </div>\n          )}\n        </div>\n      );\n    });\n  }, [displayTracks`
);

fs.writeFileSync('src/App.tsx', code);

import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

# 1. Fix header font size
code = code.replace(
    "fontSize: 'var(--list-font-size-xs)'",
    "fontSize: '11px'"
)

# 2. Fix colOrder default
code = code.replace(
    "const [colOrder, setColOrder] = useState<string[]>(['art', 'fileName', 'trackNumber', 'title', 'artist', 'album']);",
    "const [colOrder, setColOrder] = useState<string[]>(['fileName', 'trackNumber', 'title', 'artist', 'album']);"
)
code = code.replace(
    "if (!updatedColOrder.includes('art')) updatedColOrder = ['art', ...updatedColOrder];",
    "updatedColOrder = updatedColOrder.filter(c => c !== 'art');"
)

# 3. Rewrite Header `#` column to perfectly match Row `#` layout and remove IDX
target_header_idx = '''                  <div className="relative flex-shrink-0 flex items-center h-full" style={{ width: colWidths.index }}>
                    <div className="w-16 flex-shrink-0 flex items-center justify-center text-[var(--theme-textDim)]">
                      #
                    </div>
                    <div className="flex-1 flex-shrink-0 flex items-center justify-center text-[var(--theme-textDim)]">
                      IDX
                    </div>
                    <div onMouseDown={(e) => handleColMouseDown(e, 'index')} className="absolute right-0 top-0 bottom-0 w-[14px] cursor-col-resize flex justify-center z-20 group" style={{ transform: 'translateX(50%)' }}>
                      <div className="w-[1px] h-full bg-[var(--theme-border)] opacity-40 group-hover:bg-[var(--theme-accent)] group-hover:opacity-100 transition-colors" />
                    </div>
                  </div>'''
replacement_header_idx = '''                  <div className="relative flex-shrink-0 flex items-center h-full" style={{ width: colWidths.index }}>
                    <div className="w-16 flex-shrink-0 h-full"></div>
                    <div className="flex-1 flex-shrink-0 flex items-center justify-center text-[var(--theme-textDim)]">
                      #
                    </div>
                    <div onMouseDown={(e) => handleColMouseDown(e, 'index')} className="absolute right-0 top-0 bottom-0 w-[14px] cursor-col-resize flex justify-center z-20 group" style={{ transform: 'translateX(50%)' }}>
                      <div className="w-[1px] h-full bg-[var(--theme-border)] opacity-40 group-hover:bg-[var(--theme-accent)] group-hover:opacity-100 transition-colors" />
                    </div>
                  </div>'''
code = code.replace(target_header_idx, replacement_header_idx)

# 4. Make ART fixed in the Header
target_header_art_map = '''                    {colOrder.map(col => {
                      if (col === 'art' && colVisibility.art) {
                        return (
                          <div key="art" draggable onDragStart={(e) => handleColDragStart(e, 'art')} onDragOver={handleColDragOver} onDrop={(e) => handleColDrop(e, 'art')} className="relative flex-shrink-0 flex items-center pl-1 cursor-grab" style={{ width: colWidths.art }}>
                            ART
                            <div onMouseDown={(e) => handleColMouseDown(e, 'art')} className="absolute right-0 top-0 bottom-0 w-[14px] cursor-col-resize flex justify-center z-20 group" style={{ transform: 'translateX(50%)' }}>
                              <div className="w-[1px] h-full bg-[var(--theme-border)] opacity-40 group-hover:bg-[var(--theme-accent)] group-hover:opacity-100 transition-colors" />
                            </div>
                          </div>
                        );
                      }'''
replacement_header_art_fixed = '''                    {colVisibility.art && (
                      <div className="relative flex-shrink-0 flex items-center justify-center" style={{ width: colWidths.art }}>
                        ART
                        <div onMouseDown={(e) => handleColMouseDown(e, 'art')} className="absolute right-0 top-0 bottom-0 w-[14px] cursor-col-resize flex justify-center z-20 group" style={{ transform: 'translateX(50%)' }}>
                          <div className="w-[1px] h-full bg-[var(--theme-border)] opacity-40 group-hover:bg-[var(--theme-accent)] group-hover:opacity-100 transition-colors" />
                        </div>
                      </div>
                    )}
                    {colOrder.map(col => {
                      if (col === 'art') return null;'''
code = code.replace(target_header_art_map, replacement_header_art_fixed)

# 5. Make ART fixed in the Row
target_row_art_map = '''              {colOrder.map(col => {
                if (col === 'art' && colVisibility.art) {
                  return (
                    <div key="art" className="h-8 flex-shrink-0 border flex items-center justify-center overflow-hidden relative" style={{ width: colWidths.art, borderColor: track.missing ? 'var(--theme-accent)' : 'var(--theme-border)', backgroundColor: 'var(--theme-bg)', opacity: track.missing ? 0.5 : 1 }}>
                       {track.coverUrl ? (
                          <img src={track.coverUrl} className="w-full h-full object-cover" alt="" />
                       ) : (
                          <Activity size={10} style={{ color: 'var(--theme-textDim)' }} />
                       )}
                    </div>
                  );
                }'''
replacement_row_art_fixed = '''              {colVisibility.art && (
                <div className="h-8 flex-shrink-0 border flex items-center justify-center overflow-hidden relative" style={{ width: colWidths.art, borderColor: track.missing ? 'var(--theme-accent)' : 'var(--theme-border)', backgroundColor: 'var(--theme-bg)', opacity: track.missing ? 0.5 : 1 }}>
                   {track.coverUrl ? (
                      <img src={track.coverUrl} className="w-full h-full object-cover" alt="" />
                   ) : (
                      <Activity size={10} style={{ color: 'var(--theme-textDim)' }} />
                   )}
                </div>
              )}
              {colOrder.map(col => {
                if (col === 'art') return null;'''
code = code.replace(target_row_art_map, replacement_row_art_fixed)

with open('src/App.tsx', 'w') as f:
    f.write(code)
print("Done final fix")

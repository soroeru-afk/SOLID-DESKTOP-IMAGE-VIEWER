import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

target = '''                  <div className="relative flex-shrink-0 flex items-center justify-center" style={{ width: colWidths.index }}>
                    #
                    <div onMouseDown={(e) => handleColMouseDown(e, 'index')} className="absolute right-0 top-0 bottom-0 w-[14px] cursor-col-resize flex justify-center z-20 group" style={{ transform: 'translateX(50%)' }}>'''
replacement = '''                  <div className="relative flex-shrink-0 flex items-center h-full" style={{ width: colWidths.index }}>
                    <div className="w-16 flex-shrink-0 flex items-center justify-center text-[var(--theme-textDim)]">
                      #
                    </div>
                    <div className="flex-1 flex-shrink-0 flex items-center justify-center text-[var(--theme-textDim)]">
                      IDX
                    </div>
                    <div onMouseDown={(e) => handleColMouseDown(e, 'index')} className="absolute right-0 top-0 bottom-0 w-[14px] cursor-col-resize flex justify-center z-20 group" style={{ transform: 'translateX(50%)' }}>'''
code = code.replace(target, replacement)

with open('src/App.tsx', 'w') as f:
    f.write(code)

print("Done")
